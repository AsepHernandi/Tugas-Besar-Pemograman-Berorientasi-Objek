package DeluxeShop;

/**
 *
 * @author Administrator
 */
class Gucci extends Produk {
    public Gucci(String nama, double harga) {
        super(nama, harga);
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Gucci - " + getNama() + ", Harga: Rp. " + getHarga() + getDiskonInfo());
    }

    private String getDiskonInfo() {
        if (isDiskonBerlaku()) {
            return " (Diskon " + getPersenDiskon() + "%)";
        } else {
            return "";
        }
    }
}