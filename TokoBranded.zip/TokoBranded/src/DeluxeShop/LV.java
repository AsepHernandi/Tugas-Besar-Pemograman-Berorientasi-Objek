package DeluxeShop;

/**
 *
 * @author Administrator
 */
class LV extends Produk {
    public LV(String nama, double harga) {
        super(nama, harga);
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("LV - " + getNama() + ", Harga: Rp. " + getHarga() + getDiskonInfo());
    }

    private String getDiskonInfo() {
        if (isDiskonBerlaku()) {
            return " (Diskon " + getPersenDiskon() + "%)";
        } else {
            return "";
        }
    }
}
