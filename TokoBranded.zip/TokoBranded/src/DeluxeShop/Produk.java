package DeluxeShop;

/**
 *
 * @author Administrator
 */
import java.util.Scanner;

// Kelas abstrak untuk produk
abstract class Produk {
    private String nama;
    private double harga;
    private boolean diskonBerlaku;
    private double persenDiskon;

    public Produk(String nama, double harga) {
        this.nama = nama;
        this.harga = harga;
        this.diskonBerlaku = false;
        this.persenDiskon = 0;
    }

    // Getter dan setter untuk atribut nama
    public String getNama() {
        return nama;
    }

    // Getter dan setter untuk atribut harga
    public double getHarga() {
        return harga;
    }

    // Getter dan setter untuk atribut diskonBerlaku
    public boolean isDiskonBerlaku() {
        return diskonBerlaku;
    }

    // Getter dan setter untuk atribut persenDiskon
    public double getPersenDiskon() {
        return persenDiskon;
    }

    // Setter untuk atribut diskonBerlaku dan persenDiskon
    public void setDiskon(double persenDiskon) {
        this.diskonBerlaku = true;
        this.persenDiskon = persenDiskon;
    }

    // Metode untuk menghapus diskon
    public void hapusDiskon() {
        this.diskonBerlaku = false;
        this.persenDiskon = 0;
    }

    // Metode abstrak untuk menampilkan informasi produk
    public abstract void tampilkanInfo();
}