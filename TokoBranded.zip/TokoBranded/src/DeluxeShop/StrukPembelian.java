package DeluxeShop;

/**
 *
 * @author Administrator
 */
interface StrukPembelian {

    void BagianAtas();

    void BagianBawah();
}

class Struk implements StrukPembelian {

    @Override
    public void BagianAtas() {
        System.out.println("===============================================");
        System.out.println("              *** DELUXE SHOP ***              ");
        System.out.println("              Toko Barang Branded              ");
        System.out.println("===============================================");
    }

    @Override
    public void BagianBawah() {
        // Menampilkan Struk Bagian Bawah
        System.out.println("\n      Terima kasih telah berbelanja !        ");
        System.out.println("===============================================");
        System.out.println("                  Deluxe Shop                  ");
        System.out.println("   Jalan Pegangsaan Timur No. 45, Kota Bandung ");
        System.out.println("===============================================");
        System.out.println("          Terima Kasih & Sampai Jumpa!         ");
    }

}
