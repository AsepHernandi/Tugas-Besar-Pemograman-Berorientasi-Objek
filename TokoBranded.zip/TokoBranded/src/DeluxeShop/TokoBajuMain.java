package DeluxeShop;

/**
 *
 * @author Administrator
 */
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.List;

// Kelas utama
public class TokoBajuMain implements StrukPembelian {

    @Override
    public void BagianAtas() {
        System.out.println("===============================================");
        System.out.println("              *** DELUXE SHOP ***              ");
        System.out.println("              Toko Barang Branded              ");
        System.out.println("===============================================");
    }

    @Override
    public void BagianBawah() {
        System.out.println("\n        Terima kasih telah berbelanja !      ");
        System.out.println("===============================================");
        System.out.println("                  Deluxe Shop                  ");
        System.out.println("                  08154334577                  ");
        System.out.println("   Jalan Pegangsaan Timur No. 45, Kota Bandung ");
        System.out.println("===============================================");
        System.out.println("          Terima Kasih & Sampai Jumpa!         ");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StrukPembelian Struk = new Struk();
        Struk.BagianAtas();
        // Menu produk
        Produk[] produkArr = {
            new LV("Kaos Logo LV", 350),
            new LV("Sweater Winter Edition", 1200),
            new Gucci("Tas Gucci Valentine edition", 8500),
            new Gucci("Kemeja Putih Logo", 400),
            new Supreme("Sepatu Supreme x Nike", 3500),
            new Supreme("Jacket Supreme Hitam", 2200),
            new Celana("Celana Putih prada", 300),
            new Celana("Celana Formal Zara", 200)
        };
        // Menampilkan menu
        boolean beliLagi = true;
        while (beliLagi) {
            try {
                // Menampilkan menu produk
                System.out.println("Berikut adalah menu produk:");

                for (int i = 0; i < produkArr.length; i++) {
                    System.out.println((i + 1) + ". " + produkArr[i].getNama());
                }

                // Meminta input dari pengguna
                System.out.print("Berapa banyak produk yang ingin dibeli? ");
                int jumlahProduk = scanner.nextInt();

                // List untuk menyimpan produk yang dipilih
                List<Produk> produkDibeli = new ArrayList<>();

                // Memilih produk sejumlah jumlahProduk
                for (int i = 0; i < jumlahProduk; i++) {
                    System.out.print("Pilih nomor produk ke-" + (i + 1) + ": ");
                    int pilihan = scanner.nextInt();

                    // Validasi pilihan
                    if (pilihan < 1 || pilihan > produkArr.length) {
                        System.out.println("Pilihan tidak valid. Program berhenti.");
                        return;
                    }

                    // Menambahkan produk ke dalam list
                    produkDibeli.add(produkArr[pilihan - 1]);
                }

                if (produkDibeli.isEmpty()) {
                    System.out.println("Anda tidak membeli produk apapun.");
                } else {
                    // Menampilkan informasi produk yang dipilih
                    System.out.println("\nAnda telah memilih:");
                    for (Produk produk : produkDibeli) {
                        produk.tampilkanInfo();
                    }

                    // Menghitung total belanja
                    double totalBelanja = 0;
                    for (Produk produk : produkDibeli) {
                        totalBelanja += produk.getHarga();
                    }

                    // Menawarkan diskon jika total belanja lebih dari Rp. 1000
                    if (totalBelanja > 1000) {
                        System.out.println("Selamat! Anda mendapatkan diskon 15% Karena total belanja Anda lebih dari Rp. 1000");
                        totalBelanja *= 0.85; // Diskon 15%
                    }

                    // Menampilkan total belanja
                    System.out.println("===============================================");
                    System.out.println("Total Belanja                       : Rp. " + totalBelanja);

                    // Pembayaran
                    System.out.print("Masukkan jumlah uang yang dibayarkan: Rp. ");
                    double jumlahDibayarkan = scanner.nextDouble();

                    // Validasi pembayaran
                    if (jumlahDibayarkan < totalBelanja) {
                        System.out.println("===============================================");
                        System.out.println("Mohon Maaf Jumlah Yang Anda Bayarkan Kurang !");
                        return;
                    }

                    // Menghitung kembalian
                    double kembalian = jumlahDibayarkan - totalBelanja;

                    // Menampilkan struk pembelian
                    System.out.println("===============================================");
                    System.out.println("                 STRUK PEMBELIAN               ");
                    System.out.println("===============================================");
                    for (Produk produk : produkDibeli) {
                        produk.tampilkanInfo();
                    }
                    System.out.println("-----------------------------------------------");
                    System.out.println("Total Belanja  : Rp. " + totalBelanja);
                    System.out.println("Uang Dibayarkan: Rp. " + jumlahDibayarkan);
                    System.out.println("Kembalian      : Rp. " + kembalian);
                    System.out.println("===============================================");

                }
            } catch (InputMismatchException e) {
                System.out.println("Input yang dimasukkan bukan angka. Program berhenti.");
                return;
            }

            // Meminta input apakah pelanggan ingin membeli lagi
            System.out.print("Apakah Anda ingin membeli lagi? (ya/tidak): ");
            String jawaban = scanner.next().toLowerCase();
            beliLagi = jawaban.equals("ya");
        }
        Struk.BagianBawah();

        // Menutup scanner
        scanner.close();
    }

}
