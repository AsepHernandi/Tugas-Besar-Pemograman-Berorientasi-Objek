/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DeluxeShop;

/**
 *
 * @author Administrator
 */
class Supreme extends Produk {
    public Supreme(String nama, double harga) {
        super(nama, harga);
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Supreme - " + getNama() + ", Harga: Rp. " + getHarga() + getDiskonInfo());
    }

    private String getDiskonInfo() {
        if (isDiskonBerlaku()) {
            return " (Diskon " + getPersenDiskon() + "%)";
        } else {
            return "";
        }
    }
}